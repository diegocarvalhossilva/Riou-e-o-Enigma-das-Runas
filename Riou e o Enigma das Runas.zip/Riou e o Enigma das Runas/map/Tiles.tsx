<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Tiles" tilewidth="64" tileheight="64" tilecount="25" columns="5">
 <image source="Tiles.png" width="320" height="320"/>
</tileset>
