<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Objects" tilewidth="128" tileheight="128" tilecount="4" columns="2">
 <image source="Objects.png" width="256" height="256"/>
</tileset>
